-- Q3. check total number of rows

SELECT 
    COUNT(*) AS Total_input
FROM
    `corona virus dataset`;